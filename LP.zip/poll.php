<?php
// Retrieve the username from the session
session_start();
if (isset($_SESSION['username']) && isset($_SESSION['buttonNo'])) {
    $username = $_SESSION['username'];
    $buttonNo = $_SESSION['buttonNo'];
    // Now, you can use the $username and $buttonNo variables in your poll.php file
} else {
    // Handle the case where the username or buttonNo is not set in the session
    echo "Error: Username or button number not provided.";
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote for Your Favorite Option</title>
    <style>
        * {
            font-family: "Lato";
            color: white;
        }

        body {
            background-color: #33cfff;
            text-align: center;

            padding: 0;
            margin: 0;
        }

        .table {
            display: table;
            margin: 0 auto;
        }

        .tr {
            display: table-row;
            cursor: pointer;

            transition: all 300ms;
        }

        .td {
            display: table-cell;
            font-size: 30px;

            padding: 7px 0;

            text-align: left;
        }

        .td.check {
            padding-right: 20px;
        }

        .tr:hover {
            transform: scale(1.05);
        }

        button {
            background-color: white;
            color: #33cfff;
            border: 4px solid white;
            border-radius: 1000px;

            font-size: 30px;
            padding: 10px 30px;
            margin-top: 10px;

            cursor: pointer;

            transition: all 300ms, transform 100ms;

            opacity: 0;
        }

        button>* {
            color: #33cfff;
            transition: all 300ms;
        }

        button:not(.loading):hover>* {
            color: white;
        }

        button i {
            display: none !important;
        }

        button.loading {
            background-color: transparent;
        }

        button.loading i {
            display: inline-block !important;
            color: white;
        }

        button.loading .text {
            display: none;
        }

        button:not(.loading):hover {
            background-color: transparent;
            color: white;
        }

        button:active {
            outline: 0;
            transform: translateY(3px);
        }

        button:focus {
            outline: 0;
        }

        button.shown {
            opacity: 1;
        }

        .tr.active {
            font-weight: bold;
            transform: scale(1.1);
        }

        .tr.active i::before {
            content: "\f14a";
        }

        .tr.active i {
            font-weight: 700;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>

<body>
    <!-- Set up the question and options over in the JavaScript -->
    <div id="content">
            <!-- Display the selected username and button number -->
    <p>Selected Username: <?php echo $username; ?></p>
    <p>Selected Button Number: <?php echo $buttonNo; ?></p>
        <h1 id="question"></h1>

        <div class="table" id="table"></div>

        <button id="vote" class=""><span class="text">Vote</span><i class='fas fa-circle-notch fa-spin'></i></button>
    </div>
  <script>
    var possibleStuff = [
        {
            question: "How many Investors will invest?",
            options: [
                { value: "1", label: "0-2" },
                { value: "2", label: "3-5" },
                { value: "3", label: "6-7" },
                { value: "4", label: "8-9" },
                { value: "5", label: "All" }
            ]
        }
    ];

    var num = Math.floor(Math.random() * possibleStuff.length);

    var question = possibleStuff[num].question;
    var options = possibleStuff[num].options;

    var table = document.getElementById("table");
    document.getElementById("question").innerText = question;
    updateOptions(options);

    function updateOptions(options) {
        options.forEach(item => {
            // Create row
            var row = document.createElement("div");
            row.classList.add("tr");

            // Create cells
            var cell1 = document.createElement("div");
            cell1.classList.add("td");
            cell1.classList.add("check");
            cell1.innerHTML = "<i class='far fa-square'></i>";

            var cell2 = document.createElement("div");
            cell2.classList.add("td");
            cell2.innerText = item.label; // Use the label property for display
            cell2.setAttribute("data-value", item.value); // Set the data-value attribute for storing the value

            // Append cells to row
            row.appendChild(cell1);
            row.appendChild(cell2);

            // Append row to table
            table.appendChild(row);
        })
    }

    var rows = document.getElementsByClassName("tr");
    for (i = 0; i < rows.length; i++) {
        rows[i].addEventListener("click", function (e) {
            var active = document.querySelector(".tr.active");
            if (active) {
                active.classList.remove("active");
            }

            this.classList.add("active");

            document.getElementById("vote").classList.add("shown");
        })
    }

    document.getElementById("vote").addEventListener("click", function (e) {
        this.classList.add("loading");

        var choiceElement = document.querySelector(".tr.active .td:nth-child(2)");
        var choice = choiceElement.innerText;
        var choiceValue = choiceElement.getAttribute("data-value");

        // Now you have both the display text and the value of the selected option
        console.log("Selected Option Text: ", choice);
        console.log("Selected Option Value: ", choiceValue);

        var username = '<?php echo $username;?>';
        var buttonNo = '<?php echo $buttonNo;?>';

            // Send the selected value, username, and buttonNo to the server using AJAX
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'submit_vote.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            if (response.status === 'success') {
                // Successful vote, update content or redirect if needed
                contentElement.innerHTML = `<h2>Thank you for voting!</h2><button class="shown"><a href="buttons.php">Vote for next Pitch </a><i class='fas fa-arrow-left'></i></button>`;
            } else if (response.status === 'error') {
                // Display an alert if the user has already voted
                alert(response.message);
            }
        }
            };

            // Include the username and buttonNo in the data sent to submit_vote.php
            xhr.send('option=' + choiceValue + '&username=' + encodeURIComponent(username) + '&buttonNo=' + encodeURIComponent(buttonNo));
            setTimeout(() => {
                document.getElementById("content").innerHTML = `<h2>Thank you for voting!</h2><button class="shown"><a href="buttons.php">Vote for next Pitch </a><i class='fas fa-arrow-left'></i></button>`;
            }, 1000);
        })
    </script>
</body>

</html>